function CabinDetail() {
  return <div>CabinDetail</div>;
}

export default CabinDetail;
