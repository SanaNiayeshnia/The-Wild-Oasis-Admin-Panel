export const APP_NAME = "The Wild Oasis";
export const PAGE_SIZE = 4;
