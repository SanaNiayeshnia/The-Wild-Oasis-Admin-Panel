import styled from "styled-components";

const DesignedBy = styled.p`
  font-size: 0.85rem;
`;

export default DesignedBy;
