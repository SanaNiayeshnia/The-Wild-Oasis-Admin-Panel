import styled from "styled-components";
const Error = styled.p`
  color: var(--color-red-700);
  margin: 0;
  text-align: center;
  font-size: 0.85rem;
`;
export default Error;
