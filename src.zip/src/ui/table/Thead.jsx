import styled from "styled-components";
const Thead = styled.thead`
  background-color: var(--color-Gray-100);
`;
export default Thead;
